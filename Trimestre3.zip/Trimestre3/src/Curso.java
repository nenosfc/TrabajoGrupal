public class Curso {

    private int id_curso;
    private String nombre;
    private String asignatura;
    private String Alumnos;
}
