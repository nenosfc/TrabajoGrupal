public class asignatura {
    private int id_asignatura;
    private String asignatura;
    private int nota;
}
